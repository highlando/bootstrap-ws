function [] = addVelVec2gridvtk( xy, velVec, fName, nameScal )
	%ADDSCAL2GRIDVTK adds the velocity vectors to the cells specified
	% in xy in the vtk file grid.vtk
	%   Inputs:
	%   xy ... vector of the coordinates of the cell centers
	%   velVec ... vector of the velocities that is to be assigned to the cells
	%   nameScal ... string with the name of the vector data
	%
	%   xy and velVec have to be in the same order

	nCells = length(xy);

	if nCells ~= length(velVec)
		error('cells and data do not match')
	else
		fid = fopen(fName,'a');  % a = add new data
		fprintf(fid,'%s\n',['VECTORS ' nameScal ' float '] );
		fprintf(fid,'%e %e %e \n',[velVec'; zeros(1,nCells)]);
		fclose(fid);
	end

end

