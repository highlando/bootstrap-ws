function [] = addScal2gridvtk( xy, scal, fName, nameScal )
	%ADDSCAL2GRIDVTK adds scalar data to the cells specified
	% in xy in the vtk file grid.vtk
	%   Inputs:
	%   xy ... vector of the coordinates of the cell centers
	%   scal ... scalar data that is to be assigned to the cells
	%   nameScal ... string with the name of the scalar
	%
	%   xy and scal have to be in the same order

	nCells = length(xy);

	if nCells ~= length(scal)
		error('cells and data do not match')
	else
		fid = fopen(fName,'a');  % a = add new data
		fprintf(fid,'%s\n',['SCALARS ' nameScal ' float 1'] );
		fprintf(fid,'%s\n','LOOKUP_TABLE default'); 
		fprintf(fid,'%e\n',scal);
		fclose(fid);
	end

end

