function [ centxy ] = fvmGrid( N,xN,fName )
	%FVMGRID computes the grid for the domain
	%  _ _ 
	% |   |\
	% |   |__\
	% |       |
	% |_ _ _ _|  'an L-shaped domain with a triangle
	% embedded in [0,1]x[0,1]
	%
	% Inputs:
	% N ... Number of cells in one dimension to discretize a forth of the L uniformly
	% xN ... number of additional cells for a refinement towards the left and lower boundary
	%
	% Output:
	% centxy ... vector of the coordinates of the cell centers 
	%
	% Also output if specified: fName (.vtk) Geometry file to be read in Paraview for visualization
	%

	if nargin == 2 %If not specified no vktfile is produced
		writeVtk = 0;
	else
		writeVtk = 1;
	end
	%coordinate vectors in one dimension
	xOuter = linspace(1/2,1,N+1); 
	xInner = linspace(0,1/2,N+xN+1); %uniformly spaced so far

	alpha = (1-1/N)/(1-1/(N+xN)); %squeezing factor
	alphaVec = N+xN:-1:0;
	alphaVec = (alpha*ones(1,N+xN+1)).^alphaVec;
	xInnerSq = alphaVec.*xInner; %now squeezed
	x = union(xInnerSq,xOuter); %the whole coordinate vector


	%% Grid of [0,0.5]x[0,1]
	gridlxy = [kron(ones(2*N+xN+1,1),xInnerSq') kron((x(end:-1:1))',ones(N+xN+1,1)) ];
	centXInnerSq = 0.5*(xInnerSq(1:end-1)+xInnerSq(2:end));
	centX = 0.5*(x(1:end-1)+x(2:end));

	centlxy = [kron(ones(2*N+xN,1),centXInnerSq') kron((centX(end:-1:1))',ones(N+xN,1)) ];

	%% find the corners of the cell for every centernode
	%using the lexicographical ordering
	cornOfCentl = corForCenter((1:(N+xN)*(2*N+xN))',N+xN,2*N+xN);

	%% Grid of [0.5,1]x[0,0.5]
	gridrxy = [kron(ones(N+xN+1,1),xOuter') kron((xInnerSq(end:-1:1))',ones(N+1,1)) ];
	centrX = 0.5*(xOuter(1:end-1)+xOuter(2:end));
	centrxy = [kron(ones(N+xN,1),centrX') kron((centXInnerSq(end:-1:1))',ones(N,1))];

	%% find the corners of the cell for every centernode
	%same lexi function as above but N, xN interchanged
	cornOfCentR = corForCenter((1:(N+xN)*N)',N,N+xN);
	cornOfCentR = cornOfCentR + (N+xN+1)*(2*N+xN+1);


	%%grid for the upper left corner (triangle)
	hbase = 1/(2*N); %N cells per 1/2 
	cornOfCent = [cornOfCentl; cornOfCentR];
	gridtxy = [];
	for k=0:N
		Nkk= 2*k+1;
		for kk = 0:Nkk-1
			gridtxy = [ gridtxy ; kk*0.5*hbase (Nkk-1-kk)*0.5*hbase];
		end
	end

	% find the centers and the neighbors 
	centtxy = [];
	vtktInfo = [];
	for k=1:N
		%first cell (triangle)
		centtxy = [centtxy; 0*hbase (k-1+0.5)*hbase];
		vtktInfo = [vtktInfo; 4 (k-1)^2+1 k^2+1 k^2+2 k^2+2 ];
		%should actually by a triangle, but for easier coding
		%we treat it as a degenerate square in the visualization
		%vtktInfo = [vtktInfo; 3 k^2 (k+1)^2 (k+1)^2-1 NaN];
		%inner cells (squares)
		for kk = 2:2*k-1
			centtxy = [centtxy; (kk-1)*0.5*hbase (k-1)*hbase-(kk-2)*0.5*hbase];
			kkk = kk-2;
			vtktInfo = [vtktInfo; 4 k^2+2+kkk k^2+3+kkk (k-1)^2+1+kkk (k-1)^2+2+kkk];
		end
		%last cell (triangle)
		centtxy = [centtxy; (k-1+0.5)*hbase 0*hbase];
		vtktInfo = [vtktInfo; 4 k^2 (k+1)^2 (k+1)^2-1 (k+1)^2-1];
		%should actually by a triangle, but for easier coding
		%we treat it as a degenerate square in the visualization
	end

	% embed the triangle in the L
	gridtxy=gridtxy+0.5; %offset
	centtxy=centtxy+0.5; %offset 
	npointsL=(N+xN+1)*(2*N+xN+1)+(N+1)*(N+xN+1);  %points of the L
	vtktInfo(:,2:5) = vtktInfo(:,2:5) + npointsL-1; 


	%% merge the grids and the centerpoints
	gridxy = [gridlxy; gridrxy; gridtxy];
	centxy = [centlxy; centrxy; centtxy];

	%% write the geometry file grid.vtk

	if writeVtk

		nPoints = length(gridxy);
		fid3 = fopen(fName,'w'); 
		fprintf(fid3,'%s\n','# vtk DataFile Version 3.0'); 
		fprintf(fid3,'%s\n','stirrer block 4'); 
		fprintf(fid3,'%s\n','ASCII'); 
		fprintf(fid3,'%s\n','DATASET UNSTRUCTURED_GRID'); 
		fprintf(fid3,'%s%d%s\n','POINTS ',nPoints,' float'); 
		fprintf(fid3,'%e %e %e\n',[gridxy'; ones(1,nPoints)]); 

		nfacesL=(N+xN)*(2*N+xN)+N*(N+xN);  %faces of the L
		nfacesT= (N+1)*N;
		nfaces = nfacesT+nfacesL;
		nsize=nfaces*5;

		fprintf(fid3,'%s %d %d\n','CELLS',nfaces,nsize);
		fprintf(fid3,'%d %d %d %d %d \n',[4*ones(1,nfacesL); (cornOfCent-1)']);
		fprintf(fid3,'%d %d %d %d %d \n',vtktInfo');

		fprintf(fid3,'%s %d\n','CELL_TYPES',nfaces);
		fprintf(fid3,'%d\n',8*ones(nfaces,1));

		fprintf(fid3,'%s%d\n','CELL_DATA ',nfaces );

		fclose(fid3);

	end
end

