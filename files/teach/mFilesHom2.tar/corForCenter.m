function [edgeVec] = corForCenter(nC,NX,NY);
	%% returns the indeces of the cornerNodes of cell nC, NX = number of cells in X, NY ...
	
	if max(nC) <= NX*NY
		xind = mod(nC-1,NX); 
		yind = (nC-xind-1)/(NX);
		edgeVec = [xind+1+(yind+1)*(NX+1) xind+2+(yind+1)*(NX+1) xind+1+yind*(NX+1) xind+2+yind*(NX+1)];
	else
		error('not yet implemented')
	end

