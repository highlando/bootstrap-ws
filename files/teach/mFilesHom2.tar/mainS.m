clear

%% Space discretization parameters
N = 3; % # cells per dimension in a quarter of the domain
xN = 2; % # additional cells for refinement near the wall 
theta = 0;% parameter of the theta scheme in [0,1]
					% 0 - Upwind, 1 - Central differences

%Problem parameters
u0 = 1;% velocity magnitude in the far-field

%% Time discretization 
tiyes = 0; %logical switch for Time integration
Nt = 128;
T = 2;

fileName = 'rho.vtk' %name of the output file

centxy = fvmGrid(N,xN,fileName); %x,y coordinates of cell centers

centR = sqrt(sum((centxy.^2),2)); %R,Theta coordinates of the cell centers
centTh = atan2(centxy(:,2),centxy(:,1));

% Number of cells in [L1,L2,Triangle]
nCellsL1 = (2*N+xN)*(N+xN);
nCellsL2 = N*(N+xN);
nCellsL = nCellsL1+nCellsL2;
nCellsTr = (N+1)*N;
nCells = nCellsTr+nCellsL;

% initial value for rho
rho0 = zeros(nCells,1);

% the velocities in polar coordinates
uR = u0*centR.*cos(2*centTh);
uTh = -u0*centR.*sin(2*centTh);

addVelVec2gridvtk( centxy, [uR uTh] ,fileName, 'polarVel')

%% Assembling of the matrices
A = speye(nCells);
M = speye(nCells);
rhs = spalloc(nCells,1,2*N);

	rho = A\rhs; %Solution of the stationary problem

addScal2gridvtk( centxy, full(rho),fileName, 'rho')

%% Time integration 
if tiyes

	tau = T/Nt;
	rho = rho0; %initial value
		fNamets = ['rho_0.vtk']; 
		fvmGrid(N,xN,fNamets);
		addScal2gridvtk( centxy, full(rho),fNamets, 'rho')
		fprintf('\n Computing...')

	for t = 1:8
		for tt = 1:round(Nt/8)
			%Implicit Euler
			rho = (M+0.5*tau*A)\((M-0.5*tau*A)*rho+tau*rhs);
		end
		fprintf(1, '\b\b\b%s%d%s','...',ceil(t*tt/Nt*100),'%')

		timeStep = t*tt;
		%New vtk file after some timesteps
		fNamets = ['rho_' num2str(timeStep) '.vtk'];
		fvmGrid(N,xN,fNamets);
		addScal2gridvtk( centxy, full(rho),fNamets, 'rho')
	end
end

rhoref = max(rho(N^2+1:2*N^2));


	fprintf('\n Have fun!!! \n');
